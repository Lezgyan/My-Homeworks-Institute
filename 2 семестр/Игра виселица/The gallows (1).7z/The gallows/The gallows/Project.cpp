﻿#include <iostream>
#include <set>
#include <map>
#include <time.h>
#include "Picture.h"
#include "Word.h"

using namespace std;

string get_line(int n) { // сюда будем передавать слово, которое будет 
	string r = ""; // в отдльном массиве, слова заранее напишем
	for (int i = 0; i < n; i++) {
		r += '_';
	}
	return r;
}

string myfind(const string ans, string &res, char t) { // поиск введёной буквы в слове

	for (int i = 0; i < ans.size(); i++) {
		if (ans[i] == t) {
			res[i] = t;
		}
	}
	return res;
}

set<char> get_alphabet() {
	set<char> ter;
	for (char i = 'A'; i <= 'Z'; i++) {
		ter.insert(i);
	}
	return ter;
}

void print(string k) {
	for (int z = 0; z < k.size(); z++) {
		cout << k[z] << " ";
	}
	cout << endl;
}

int main() {
	srand(time(NULL));
	while (true) {
		string we, sad;
		cout << "If you want to end the game enter stop, otherwise enter start" << endl;
		cin >> we;
		for (int b = 0; b < we.size(); b++) {
			sad += toupper(we[b]);
		}
		if (sad == "STOP") {
			break;
		}
		int cnt = 0;
		set<char> lt = get_alphabet(); // массив с буквами

		string ans = get_qestion();

		string res = get_line(ans.size());// результирующая строка

		print(res);

		bool flag = true;

		while (cnt < 6) {
			for (auto i : lt) {
				cout << i << " ";
			}
			cout << endl;
			cout << "If you want to try to guess the whole word, enter 1" << endl;
			char letter;
			cout << "Input letter ";
			cin >> letter;
			cout << endl;
			if (letter == '1') { // попытка ввести всё слово сразу
				string w, tt;
				cout << "Enter a word: ";
				cin >> w;
				for (int qaz = 0; qaz < w.size(); qaz++) {
					tt += toupper(w[qaz]);
				}
				if (tt != ans) {
					flag = false;
				}
				break;
			}
			else {
				letter = toupper(letter);
				if (lt.find(letter) == lt.end()) {
					cout << endl;
					cout << "This letter has already been entered" << endl;
					print(res);
					continue;
				}
				if (ans.find(letter) != -1) {
					myfind(ans, res, letter);
					print(res);
					if (res.find('_') == -1) {
						break;
					}

				}
				else {
					picture(cnt);
					cnt++;
					print(res);
				}
				lt.erase(letter);
			}
			cout << endl;
		}
		cout << endl;
		if (cnt >= 6 || !flag) {
			cout << "YOU LOSE!" << endl;
			cout << ans << endl;
		}
		else {
			cout << "YOU WIN!" << endl;
		}
	}
	system("pause");
	return 0;
}